const regexOnlyNumber: RegExp = new RegExp(/[^0-9]+/g);
const regexOnlyAlphanumeric: RegExp = new RegExp(/[^a-zA-Z0-9]+/g);
export class Converters {
  static getOnlyNumbers(value: any): string {
    return (value ?? "").toString().replace(regexOnlyNumber, "");
  }
  static getOnlyAlphaNumeric(value: any): string {
    return (value ?? "").toString().replace(regexOnlyAlphanumeric, "");
  }

  static toBrazilFormat(value: any): string {


    let newValue =  parseFloat(value.toString());

    const numberFomat = Intl.NumberFormat("pt-BR", {
      minimumFractionDigits: 8,
      maximumFractionDigits: 8,
    });
    return numberFomat.format(newValue);
  }

  static toEnUsFormat(value: any) : number {
    if (!value || value ===null) {
      return null;
    }

    //Index of first comma
    const posC = value.indexOf(",");

    if (posC === -1) {
      //No commas found, treat as float
      return parseFloat(value);
    }

    //Index of first full stop
    const posFS = value.indexOf(".");

    if (posFS === -1) {
      //Uses commas and not full stops - swap them (e.g. 1,23 --> 1.23)
      return parseFloat(value.replace(/\,/g, "."));
    }

    //Uses both commas and full stops - ensure correct order and remove 1000s separators
    return posC < posFS
      ? parseFloat(value.replace(/\,/g, ""))
      : parseFloat(value.replace(/\./g, "").replace(",", "."));
  }
}
