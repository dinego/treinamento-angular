import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'poc9';

  name = new FormControl('10');

  sendData() {
    console.log(this.name.value);
  }

  blurInput() {
    console.log('blur input ', this.name.value);
  }
}
