import { DecimalPipe } from '@angular/common';
import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { AbstractControl } from '@angular/forms';

@Directive({
  selector: '[appValueExtension]',
  providers: [DecimalPipe],
})
export class ValueExtensionDirective {
  @Input('beforePlaces') beforePlaces: number;
  @Input('afterPlaces') afterPlaces: number;
  @Input('fieldControl') fieldControl: AbstractControl;

  beforeDigits: any;
  afterDigits: any;

  private totalPlaces: number;

  constructor(private _el: ElementRef) {}

  @HostListener('blur') onBlur() {
    const numberFomat = Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 8,
      maximumFractionDigits: 8,
    });

    const valueReplaced = this._el.nativeElement.value
      .replace('.', '')
      .replace('.', '')
      .replace('.', '')
      .replace('.', '')
      .replace(',', '.');

    //console.log('valueReplaced ', valueReplaced);

    let numberOn = numberFomat.format(valueReplaced);

    numberOn = numberOn
      .replace('.', '')
      .replace('.', '')
      .replace('.', '')
      .replace('.', '');

    //console.log('numberOn ', numberOn);

    const ceilVerify = Math.ceil(parseFloat(numberOn));

    if (numberOn !== 'NaN' && !isNaN(ceilVerify) && ceilVerify >= 1) {
      this._el.nativeElement.value = numberOn;
    } else {
      this.fieldControl.setValue(null);
    }
  }

  @HostListener('paste', ['$event'])
  onPaste(event: ClipboardEvent) {
    let dataToPaste = event.clipboardData.getData('text');
    const initalValue = dataToPaste;

    //avoid duplicate commas
    this.parseDuplicatedCommas(dataToPaste);

    this.totalPlaces = this.beforePlaces + this.afterPlaces;

    this.parseValue(dataToPaste, true);

    if (initalValue !== this._el.nativeElement.value) {
      event.stopPropagation();
    }
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    let actualValue = this._el.nativeElement.value;

    if (event.key === 'Backspace' || event.key === 'Delete') {
      this._el.nativeElement.value = null;
    }

    if (event.ctrlKey) {
      return false;
    }

    //avoid duplicate commas
    if (!this.parseDuplicatedCommas(actualValue)) {
      event.preventDefault();
    }

    if (!/^[0-9,]$/i.test(event.key)) {
      event.preventDefault();
    } else {
      //check before places
      this.totalPlaces = this.beforePlaces + this.afterPlaces;
      this.parseValue(actualValue);
    }
  }

  private parseValue(actualValue: string, fromPaste: boolean = false) {
    if (actualValue.indexOf(',') > this.beforePlaces) {
      actualValue = actualValue.replace(',', '');
      this._el.nativeElement.value =
        actualValue.slice(0, this.beforePlaces) +
        ',' +
        actualValue.slice(this.beforePlaces, this.totalPlaces);
    } else if (
      actualValue.indexOf(',') === -1 &&
      actualValue.length > this.beforePlaces &&
      !fromPaste
    ) {
      this._el.nativeElement.value =
        actualValue.slice(0, this.beforePlaces) +
        ',' +
        actualValue.slice(this.beforePlaces, this.totalPlaces);
    } else if (
      actualValue.indexOf(',') === -1 &&
      actualValue.length > this.beforePlaces &&
      fromPaste
    ) {
      actualValue = actualValue.padEnd(this.totalPlaces, '0');
      this._el.nativeElement.value =
        actualValue.slice(0, this.beforePlaces) +
        ',' +
        actualValue.slice(this.beforePlaces, this.totalPlaces);
    }
  }

  private parseDuplicatedCommas(actualValue: string): boolean {
    let isValid: boolean = true;
    if (/,\w+,/g.test(actualValue)) {
      this._el.nativeElement.value = actualValue.substring(
        0,
        actualValue.length - 1
      );
      isValid = false;
    }
    return isValid;
  }
}
